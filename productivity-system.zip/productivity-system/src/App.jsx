import Header from "./components/Layout/Header";
import RoutineSection from "./components/RoutineSection/RoutineSection";
import TodoWidget from "./components/ToDo/TodoWidget";
import DailySchedule from "./components/Schedule/DailySchedule";

import "./App.css";

function App() {
  return (
    <div className="app">
      <Header />

      <main className="dashboard-container">
        <p>Här är dina dagliga mål och rutiner.</p>

        <div className="dashboard-grid">
          <DailySchedule />
          <TodoWidget />
        </div>

        <RoutineSection />
      </main>
    </div>
  );
}

export default App;
